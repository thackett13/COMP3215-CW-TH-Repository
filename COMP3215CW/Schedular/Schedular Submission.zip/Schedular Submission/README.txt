Hi there, the makefile may not run as i am not used to creating them, more details in the report.
I have included the librarys used as well as the visual studio project file if you need to run 
the program and the makefile doesnt function. I have also included the required instructional video
which provideds a full demonstration of the system.